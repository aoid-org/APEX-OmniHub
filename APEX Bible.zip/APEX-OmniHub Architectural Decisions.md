APEX-OmniHub Architectural Decision Records (ADRs)
"Decisions made in the past define the constraints of the future. We document them so we don't repeat the mistakes."

ADR-001: The Iron Law of Determinism
Context: In traditional distributed systems, failures are treated as exceptions. In agentic systems, failures are often treated as "hallucinations" or "drift".

Decision: We adopt the "Iron Law": If it is not deterministic, it is a bug. All core logic must be replayable. Randomness (UUID generation, timestamps, AI inference) must be injected as inputs, not generated within the workflow logic.

Consequences:

Pros: Perfect auditability, time-travel debugging (Chronos), zero-drift execution.
Cons: Requires strict discipline. Cannot use datetime.now() or random() inside workflows. Development overhead is higher.
ADR-002: Python for the Orchestrator ("The Brain")
Context: The frontend is TypeScript (React). The edge functions are TypeScript (Deno). However, the core orchestration logic needs to integrate heavily with AI libraries.

Decision: We use Python 3.11+ for the Orchestrator service.

Consequences:

Pros: Native access to PyTorch, OpenAI SDK, LangChain/Instructor. First-class support for Temporal Python SDK.
Cons: Introduction of a second language/runtime (polyglot repo). Requires Python hygiene (venv, pip, ruff).
ADR-003: Temporal.io as the State Engine
Context: We need durable execution. If the server crashes, the workflow must resume exactly where it left off.

Decision: We use Temporal.io as the underlying state engine.

Consequences:

Pros: Solves the "dual write" problem. Handles retries, timeouts, and compensation logic out of the box. code-first workflows.
Cons: Operational complexity (requires Temporal Server). Learning curve for developers (Workflow vs Activity constraints).
ADR-004: Supabase as the Universal Backend
Context: We need a relational database, authentication, vector storage for RAG, and realtime subscriptions.

Decision: We use Supabase (PostgreSQL).

Consequences:

Pros: All-in-one. pgvector for embedding storage. Built-in Auth with Row Level Security (RLS). Realtime WebSocket support.
Cons: Vendor lock-in (mitigated by being open-source PostgreSQL under the hood).
ADR-005: Capacitor for "Edge-First" Mobile
Context: We need a native mobile presence (iOS/Android) but cannot afford to maintain three separate codebases (Web, iOS, Android).

Decision: We use Capacitor to wrap the React PWA.

Consequences:

Pros: Single codebase. Access to native device features (Biometrics, Push, Haptics). "Write once, run everywhere".
Cons: Performance overhead compared to pure native (Swift/Kotlin). UI must be carefully tuned to feel "native".
ADR-006: The "Anti-OS" Strategy
Context: The market is flooded with "platforms" that let you build things. We want to build a controller that operates things.

Decision: We position APEX-OmniHub as an "Anti-OS" (Synchronized Orchestrator). It does not passively host apps; it actively drives them.

Consequences:

Pros: Strong market differentiation. Clear value proposition (Control/Governance).
Cons: Requires a paradigm shift for users who expect a passive tool.