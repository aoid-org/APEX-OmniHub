# OmniHub Platform Map — Install Pack v1.0.0

An interactive 3D map of the 11 OmniHub platform capabilities, packaged as
an additive landing-page **section** for apexomnihub.icu.

## What's in this pack

```
omnihub-starmap/
├── INSTALL.json              ← Machine-readable manifest (agent reads this)
├── AGENT_PROMPT.md           ← Step-by-step agent instructions
├── README.md                 ← This file
├── embed/
│   ├── omnihub-starmap.js    ← Self-contained engine (drop into /public)
│   └── OmniHubPlatformMap.jsx← React wrapper (drop into /src/components)
├── preview/
│   └── index.html            ← Open in a browser to preview locally
└── patches/
    └── landing-page.snippet.jsx ← Exact JSX snippet to paste in the page
```

## How to install (for the agent)

Feed the entire `omnihub-starmap/` directory to a coding agent
(Jules / Codex / Claude Code) and point it at `AGENT_PROMPT.md`. The prompt
is self-contained and references `INSTALL.json` for paths and verification.

## How to preview (for you)

```bash
cd omnihub-starmap/preview
python3 -m http.server 8000
# open http://localhost:8000
```

You'll see the section sandwiched between two placeholder sections. Click
**Explore the map**, fly the 11 capabilities, try each capability's demo,
and confirm the wiring before merging.

## Brand alignment (verified against production)

- **Colors** (from `apexomnihub.icu` CSS):
  - `#060a13` background, `#0f1729` surface, `#1e293b` elevated
  - `#c4571c` accent, `#ea7c44` accent-hover
  - `#f8fafc` text, `#cbd5e1` secondary, `#94a3b8` muted
- **Fonts**: Space Grotesk + Space Mono (already loaded by the site)
- **Capability names**: byte-for-byte match to the existing Platform
  Capabilities grid

## What this section does NOT do

- Does not repeat hero copy ("Universal Sync Orchestrator" appears nowhere).
- Does not replace the existing Platform Capabilities grid (it lives after it).
- Does not change global styles or design tokens.
- Does not add npm dependencies.

## Rollback

Single-commit revert. The change touches three files: one new public asset,
one new component, one insertion in the landing page.

## Version

`1.0.0` — Initial install pack.
