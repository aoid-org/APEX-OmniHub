# Agent Execution Prompt — Install OmniHub Platform Map

You are a coding agent executing inside the **apexomnihub.icu** site repository
(React + Vite, the same codebase that builds the existing `/assets/js/index-*.js`
bundle currently served in production).

Your job is to install the **Platform Map** feature section as an additive,
single-commit change. Follow this exact sequence. Do not improvise.

---

## 0. Pre-flight (read first, write nothing yet)

1. Read `INSTALL.json` in this package — it is the source of truth for paths,
   verification, and rollback.
2. Locate the **landing page composition file** — the file that renders the
   page at `/`. Likely candidates: `src/pages/Home.tsx`, `src/pages/Home.jsx`,
   `src/pages/Landing.*`, or `src/App.*`. Confirm by grepping for the existing
   hero copy `"The Universal"` or `"Universal Sync"` — the file containing
   that text is the landing page.
3. Locate the existing **Platform Capabilities** section in that file. It is
   the feature grid containing `OmniPort`, `OmniDash`, `Tri-Force`,
   `OmniTrace`, `MAN Mode`, etc. Note its component name and position.
4. Locate the existing **primary CTA** (`Request Early Access`) and the
   existing **demo link** (`/demo`). Note the actual `href`/anchor used.
5. Confirm fonts: the page already loads `Space Grotesk` + `Space Mono` from
   Google Fonts (verified). No font work needed.

If any of steps 2–4 cannot be confirmed, **stop and report** rather than
guessing.

---

## 1. Copy the two files

| From (this package) | To (target repo)                       |
|---------------------|-----------------------------------------|
| `embed/omnihub-starmap.js`        | `public/omnihub-starmap.js`             |
| `embed/OmniHubPlatformMap.jsx`    | `src/components/OmniHubPlatformMap.jsx` (or `.tsx` if the project is TypeScript — change the extension, the code is type-compatible) |

Copy byte-for-byte. Do **not** transform, minify, or reformat
`omnihub-starmap.js` — the bundler should treat it as a static public asset.

---

## 2. Wire into the landing page

Open the landing page composition file you identified in step 0.2.

**Add this import** with the other component imports:

```jsx
import OmniHubPlatformMap from '../components/OmniHubPlatformMap';
```

Adjust the relative path to match the file's actual location.

**Insert the component** in the JSX immediately AFTER the existing
"Platform Capabilities" feature grid section and BEFORE the
"Request Early Access" / footer CTA section:

```jsx
<OmniHubPlatformMap
  ctaHref="REPLACE_WITH_THE_ACTUAL_EARLY_ACCESS_HREF_FROM_STEP_0_4"
  demoHref="/demo"
/>
```

The `ctaHref` value MUST match the existing primary CTA on the page. If the
existing CTA is an anchor (e.g. `#early-access`), use that. If it's a route
(e.g. `/early-access`), use that. **Do not invent a new target.**

---

## 3. Verify locally

Run:

```bash
npm install        # only if needed
npm run build
npm run preview    # or the project's equivalent (vite preview)
```

Open the preview URL and confirm:

- [ ] The new section appears below the existing Platform Capabilities grid
      and above the early-access CTA — not next to the hero.
- [ ] The section's headline reads **"Every capability. One map you can fly."**
      (not the hero's "Universal Sync Orchestrator" — verify no duplication).
- [ ] Clicking **"Explore the map"** opens a fullscreen overlay.
- [ ] The overlay's first capability is **OmniPort**. The 11 capability names
      match the existing Platform Capabilities grid exactly.
- [ ] Clicking **"Try it"** on a capability reveals a hands-on interactive
      preview that is feature-relevant (e.g. on Policy Enforcement Engine
      you can toggle 4 named policy rules and test an action).
- [ ] At the final capability, the primary button reads
      **"Request Early Access"** and routes to the same target as the page's
      existing primary CTA.
- [ ] The **Watch the Maestro Demo** button routes to `/demo`.
- [ ] **Esc** closes the overlay. Arrow keys navigate. Tab order is sensible.
- [ ] On mobile width, the capability panel becomes a bottom sheet.
- [ ] Browser console shows no new errors.

If any check fails, fix before opening the PR. Do not ship a partial install.

---

## 4. Commit

Single commit. Message:

```
feat(landing): add interactive Platform Map section

Adds an additive section between Platform Capabilities and the early-access
CTA. Launches a fullscreen interactive 3D map of the 11 platform capabilities
with feature-relevant hands-on demos. Self-contained engine in
public/omnihub-starmap.js (no new npm deps). Reversible via single-commit
revert.
```

Files in the commit:
- `public/omnihub-starmap.js` (new)
- `src/components/OmniHubPlatformMap.jsx` (new — or `.tsx`)
- the landing page file (modified — exactly one import added, one component inserted)

**No other files should change.** If your tooling auto-formats unrelated
files, revert those hunks before committing.

---

## 5. Open the PR

Title: `feat(landing): interactive Platform Map section`

Body:

```
## What
Adds an interactive 3D Platform Map as a new section on the landing page,
between the existing Platform Capabilities grid and the early-access CTA.

## Why
Lets visitors actually try each capability hands-on (~2 min flow) before
requesting access. Eleven capability names and descriptions match the
existing Platform Capabilities section exactly — no duplicate messaging
with the hero.

## How
- New public asset: `public/omnihub-starmap.js` (self-contained engine,
  scoped CSS under `.ohsm-*`, three.js loaded from CDN with override).
- New component: `src/components/OmniHubPlatformMap.jsx` (loads script
  once, mounts the section).
- One insertion in the landing page file.

## Brand alignment
- Fonts: Space Grotesk + Space Mono (already loaded by site).
- Colors: `--color-orange #c4571c`, `--color-orange-light #ea7c44`,
  `--color-surface #0f1729`, `--bg-primary #060a13`, `--color-text-primary
  #f8fafc` — all sourced from the site's production CSS tokens.
- Hero messaging is NOT repeated; this is a feature section.

## Rollback
Single-commit revert. Additive change only.

## Risk
Low. No backend changes, no new dependencies (three.js via CDN with
override option). Graceful no-WebGL fallback ships with the engine.
```

---

## 6. Do NOT do any of these

- Do not edit the hero section.
- Do not duplicate the "Universal Sync Orchestrator" headline anywhere.
- Do not change global CSS or design tokens.
- Do not add new npm dependencies.
- Do not modify any backend, Supabase, or edge-function code.
- Do not change i18n files (i18n is a follow-up task; English-only ship is acceptable per `INSTALL.json`).
- Do not minify or reformat `omnihub-starmap.js`.

Report completion with: the commit SHA, the PR URL, and a one-line
confirmation that all checks in section 3 passed.
