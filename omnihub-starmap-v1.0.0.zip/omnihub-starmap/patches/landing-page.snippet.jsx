// ─────────────────────────────────────────────────────────────
// Exact insertion snippet for the landing page composition file
// (e.g. src/pages/Home.jsx).
// Place this BELOW the existing PlatformCapabilities section
// and ABOVE the early-access CTA / footer.
// ─────────────────────────────────────────────────────────────

// 1. Add at the top of the file with other imports:
import OmniHubPlatformMap from '../components/OmniHubPlatformMap';

// 2. In the JSX, after the existing capabilities grid:

{/* ...existing <PlatformCapabilities /> or equivalent section above... */}

<OmniHubPlatformMap
  ctaHref="#early-access"  /* ← replace with the actual primary-CTA target used on this page */
  demoHref="/demo"         /* ← verified: matches the existing demo route */
/>

{/* ...existing <RequestEarlyAccess /> / footer CTA section below... */}
