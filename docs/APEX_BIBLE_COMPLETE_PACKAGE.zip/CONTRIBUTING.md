# Contributing to the APEX Bible

The APEX Bible is canonical. Changes ship through the same governance the
Bible itself prescribes.

## Change Categories

| Change | Required artifact |
|---|---|
| Typo, broken link, formatting | PR only |
| Clarification (no policy change) | PR only |
| Tightening an existing policy | PR + 1 architecture reviewer + 1 leadership reviewer |
| Loosening or relaxing a policy | RFC + architecture review + leadership approval |
| New policy document | RFC + architecture review + leadership approval |
| Doctrine principle add/remove/edit | RFC + architecture review + leadership approval + ADR |
| CI script change | PR + 1 architecture reviewer + green policy report attached |

## PR Hygiene

- one logical change per PR
- title prefix:
  - `docs:` for doc-only
  - `policy:` for policy doc additions/edits
  - `ci:` for CI policy or workflow changes
  - `doctrine:` for doctrine edits (rare)
- the PR template `Governance` section must be completed
- if architecture-impacting, include RFC link

## Local Validation

Before pushing:

```sh
make apex-verify
```

This runs the full local validation suite: policy check (human + JSON
report), markdown link check (if installed), and gitleaks dry-run (if
installed).

## Style

- terse, decision-tree-driven prose
- prefer tables over paragraphs for policies
- every policy file starts with: `Version`, `Owner`, `Applies To`
- no marketing language; no hedging
- examples must be runnable or specific
- forbidden words inside policy docs: "should consider", "might want to",
  "in some cases" (be definitive; if optional, say "optional:")

## Versioning

- governance package follows SemVer
- bump PATCH for doc edits without policy change
- bump MINOR for new policy or expanded scope
- bump MAJOR for breaking removal or backward-incompatible policy change
- update `CHANGELOG.md` on every bump
- update `package_manifest.json` version on every bump and run
  `make apex-manifest` to refresh SHA-256 hashes
